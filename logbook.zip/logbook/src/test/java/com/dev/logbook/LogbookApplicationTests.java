package com.dev.logbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
